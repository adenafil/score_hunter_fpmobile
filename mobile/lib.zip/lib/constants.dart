import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xFF7A72FF); // Warna utama
const kPrimaryColor50 = Color(0x7F7A72FF);
const kSecondaryColor = Color(0xFFD3D3D3); // Warna sekunder
const kAccentColor = Color(0xFF252A4A); // Warna aksen
const kBackgroundColor = Color(0xFF202342); // Warna latar belakang
const kBackgroundColorDarken = Color(0xFF181B31);
const kTransparentWhite = Color(0x80FFFFFF); // Warna putih transparan (50%)
